-- Create the frame
local delvinFrame = CreateFrame("frame", "delvinFrame")
delvinFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
delvinFrame:RegisterEvent("WEEKLY_REWARDS_UPDATE")
delvinFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")


------ACCESSIBLE VARIABLES-------
local delveTiles = {
	{tileIndex = 18,vaultIndex = 4,delvesNeeded = 2,topDelves = {0}},
	{tileIndex = 19,vaultIndex = 5,delvesNeeded = 4,topDelves = {0}},
	{tileIndex = 20,vaultIndex = 6,delvesNeeded = 8,topDelves = {0}}
}	

local activitiesTipText = ""

-- Finds vault tile index and reward threshold in the delve progress table (delveTiles)
local delveTileNum1 = 18
local delveTileNum2 = 19
local delveTileNum3	= 20		

local topDelves1
local topDelves2
local topDelves3

local delvesNeeded1
local delvesNeeded2
local delvesNeeded3
			
--local delvenTipContainer
			
local delvinTipText1
local delvinTipText2
local delvinTipText3

local delvinHooksSet = false -- Flag to ensure hooks are set only once

			
delvinFrame:SetScript("OnEvent", 
	function(self, event, ...)		

		local delvinTipContainer = self:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		delvinTipContainer:SetText("\n0 Delves Completed" .. "\n\n" .. activitiesTipText)	
			
		-----------FUNCTIONS------------
		
		local function delvinTip1() -- as of 11.0.5 = WeeklyRewardsFrame[18]
			delvinTipContainer:SetText(delvinTipText1)
			GameTooltip:AddLine(delvinTipContainer:GetText(),1,1,1)
			GameTooltip:Show()
		end
		
		local function delvinTip2() -- as of 11.0.5 = WeeklyRewardsFrame[19]							
			delvinTipContainer:SetText(delvinTipText2)
			GameTooltip:AddLine(delvinTipContainer:GetText(),1,1,1)
			GameTooltip:Show()
		end
		
		local function delvinTip3() -- as of 11.0.5 = WeeklyRewardsFrame[20]				
			delvinTipContainer:SetText(delvinTipText3)
			GameTooltip:AddLine(delvinTipContainer:GetText(),1,1,1)
			GameTooltip:Show()
		end
		
		local function delvinClear()
			GameTooltip:ClearLines()
			GameTooltip:Hide()
		end

			
		--DUMP HELPER - STRING OUTPUT OF DevTools_Dump()
		local function dump(o)
		   if type(o) == 'table' then
			  local s = '{ '
			  for k,v in pairs(o) do
				 if (type(k) ~= 'number') then 
				k = '"'..k..'"' 
			 end
				 s = s .. '['..k..'] = ' .. dump(v) .. ','
			  end
			  return s .. '} '
		   else
			  return tostring(o)
		   end
		end

		--To split big dumps >255 chars so they can be printed in chat, for debugging
		local function splitDump(str, num)
			local result = {}
			for i = 1, #str, num do
				table.insert(result, str:sub(i, i + num - 1))
			end
			return result
		end
		
		
		--SEE IF WEEKLY RESET HAS HAPPENED--
		local function checkReset()
			local delvinCurrentTime = GetServerTime()
			local secsToReset = C_DateAndTime.GetSecondsUntilWeeklyReset()
			
			if delvinNextReset < delvinCurrentTime+secsToReset then
				delvinNextReset = delvinCurrentTime+secsToReset

				dTable = {}				
				otherActivities = 0
			end
		end
		
		--GET NON-DELVE ACTIVITIES
		local function getOtherActivities()
			-- Find # of delve runs
			local totalDelveRuns = #dTable

			-- Find # of total activities	
			local weeklyActivities = dump(C_WeeklyRewards.GetActivities())
			local activityPattern = '%["progress"%] = (%d+)' 
			local activityProgress = -math.huge

			for weeklyProgress in string.gmatch(weeklyActivities, activityPattern) do
				local weeklyProgressNumber = tonumber(weeklyProgress)
				if weeklyProgressNumber > activityProgress then
					activityProgress = weeklyProgressNumber
				end
			end

			-- Get total # of non-delve activities - subtract Delve runs from total activities
			otherActivities = activityProgress-totalDelveRuns
		end
		
		
		--FIND BEST 2, 4, 8 DELVE RUNS
		local function getNBestRuns(t, n)
			table.sort(t, function(a, b) return a.tier > b.tier end)
			
			local delvinRuns = {}
			
			for i = 1, n do
				if t[i] then
					table.insert(delvinRuns, t[i])
				end
			end
			
			local topRuns = {}
			for _, delvinRun in ipairs(delvinRuns) do
				table.insert(topRuns, delvinRun.tier .. " - " .. delvinRun.zone)
			end
			
			return topRuns	
		end

		
		--ON VAULT TILE HOVER, GET THE FRAME INDEX OF THE HOVERED OBJECT (WORLD ACTIVITY VAULT TILE) AND FIND THE MATCHING DELVES & THRESHOLD FROM DELVETILES TABLE
		local function matchProgress(delveTiles, frameIndexNum)
				for _, delveTile in ipairs(delveTiles) do 
					if delveTile.tileIndex == frameIndexNum then
							return delveTile.topDelves, delveTile.delvesNeeded
					end
				end
		end
		
		
		--SORT BEST RUNS INTO TABLE
		local function delvinTrack()
			-- First scenario: the two best runs
			local twoBest = getNBestRuns(dTable, 2)
			delveTiles[1].topDelves = twoBest

			-- Second scenario: the four best runs
			local fourBest = getNBestRuns(dTable, 4)
			delveTiles[2].topDelves = fourBest

			-- Third scenario: the eight best runs
			local eightBest = getNBestRuns(dTable, 8)
			delveTiles[3].topDelves = eightBest
			
			topDelves1, delvesNeeded1 = matchProgress(delveTiles, delveTileNum1)
			topDelves2, delvesNeeded2 = matchProgress(delveTiles, delveTileNum2)
			topDelves3, delvesNeeded3 = matchProgress(delveTiles, delveTileNum3)
			
			getOtherActivities() -- MUST come after delvinTrack, because it depends on calculation of most recent delve runs
			activitiesTipText = otherActivities.." Non-Delve World Activities"

		end		
		
		------------EVENTS---------------

		if event == "PLAYER_ENTERING_WORLD" then			
			--Reset weekly delve runs table (dTable) if server reset has occurred
			checkReset()	
			
			--Update in-game Delvin tooltips/Vault delve progress by injecting latest dTable (delve runs) into delveTiles table
			delvinTrack()
			
		--When entering a Delve, load the "SCENARIO" upate event to listen for a completed delve
    	elseif event == "ZONE_CHANGED_NEW_AREA" then
			if C_PartyInfo.IsDelveInProgress()==true then
				self:RegisterEvent("SCENARIO_CRITERIA_UPDATE")
				print("Tracking Delve")
			end
		--Listen for delve completion and update delve runs table (dTable) with delve info
		elseif event == "SCENARIO_CRITERIA_UPDATE" then	
			local delveZone =  GetZoneText()
	
			if C_PartyInfo.IsDelveComplete() == true and delveZone ~= "Zekvir's Lair" then
				self:UnregisterEvent("SCENARIO_CRITERIA_UPDATE")
				
				print("Delve complete!")
				
				local delveTier = C_CVar.GetCVar('lastSelectedDelvesTier') 
				
				table.insert(dTable,{zone = delveZone, tier = delveTier})
				
				print(delveZone.." Tier "..delveTier.." added to Delvin")
				
				delvinTrack()
			end			

		--When the Vault UI is opened, hook the tooltip display function to the World activity Vault tiles
		elseif event == "WEEKLY_REWARDS_UPDATE" then
			delvinTrack()			
			
			delvinTipText1 = "\nTop 2 Delves This Week:\n" .. table.concat(topDelves1,"\n") .. "\n\n" .. activitiesTipText
			delvinTipText2 = "\nTop 4 Delves This Week:\n" .. table.concat(topDelves2,"\n") .. "\n\n" .. activitiesTipText
			delvinTipText3 = "\nTop 8 Delves This Week:\n" .. table.concat(topDelves3,"\n") .. "\n\n" .. activitiesTipText			
			
			--Make sure the vault frame exists before applying hooks to its children, then also check whether or not the hooks have been applied
			if _G.WeeklyRewardsFrame and not delvinHooksSet then

				local wrChildFrames = {WeeklyRewardsFrame:GetChildren()}
				
				local delveTile1 = wrChildFrames[18]
				local delveTile2 = wrChildFrames[19]
				local delveTile3 = wrChildFrames[20]		
			
				delveTile1:HookScript("OnEnter", delvinTip1)
				delveTile2:HookScript("OnEnter", delvinTip2)
				delveTile3:HookScript("OnEnter", delvinTip3)	
				
				delveTile1:HookScript("OnLeave", delvinClear)
				delveTile2:HookScript("OnLeave", delvinClear)
				delveTile3:HookScript("OnLeave", delvinClear)				
				
				--Set hookSet to true so that the HookScripts don't get applied multiple times
				delvinHooksSet = true
			end
		end
	end
)


-------------------------------------------

SLASH_delvin1 = "/delvin"

SlashCmdList.delvin = function(msg, editBox)
	print("Options coming in version 1.1")
	-- check reset time /delvin nextreset
	-- reset delvin progress WILL ERASE delvin INFORMATION FOR THE CURRENT WEEK - confirmation box & button  /delvin resetdelvin
	-- manually add delve run /delvin addrun
end

------------------------------------------

